--[[
--=====================================================================================================--
Script Name: truce, for SAPP (PC & CE)
Description:

Copyright (c) 2023, Jericho Crosby <jericho.crosby227@gmail.com>
* Notice: You can use this document subject to the following conditions:
https://github.com/Chalwk77/HALO-SCRIPT-PROJECTS/blob/master/LICENSE
--=====================================================================================================--
]]--

api_version = '1.12.0.0'
local truce = {
    players = {}, cmds = {},

    -- todo: implement this (cached player tables)
    cache = {},

    settings = require('./Truce/settings'),
    dependencies = {
        ['./Truce/Misc/'] = { 'misc', 'new_player' },
        ['./Truce/Commands/'] = {
            'accept',
            'cancel',
            'decline',
            'list',
            'request',
            'requests_inbound',
            'requests_outbound',
            'untruce'
        },
        ['./Truce/Events/'] = {
            'on_command',
            'on_damage',
            'on_join',
            'on_quit',
            'on_start',
            'on_tick'
        }
    }
}

-- Loads file dependencies:
-- Each file inherits the parent truce object.
--
function truce:loadDependencies()
    local s = self

    for k, v in pairs(self.settings) do
        self[k] = v
    end

    for path, t in pairs(self.dependencies) do

        for i = 1, #t do

            local f
            local file = t[i] -- name of the file

            local success = pcall(function()
                f = loadfile(path .. file .. '.lua')()
            end)

            if (not success) then
                cprint('[TRUCE] FILE DEPENDENCY NOT FOUND: ' .. path .. file .. '.lua', 12)
                goto next
            end

            local command = self.commands[file]
            if (command) then
                local cmd = command.name
                self.cmds[cmd] = f
                self.cmds[cmd].enabled = command.enabled
                self.cmds[cmd].description = command.description
                self.cmds[cmd].level = command.level
                self.cmds[cmd].help = command.help:gsub('$cmd', cmd)
                setmetatable(self.cmds[cmd], { __index = self })
                goto next
            end

            setmetatable(s, { __index = f })
            s = f

            :: next ::
        end
    end
end

function OnScriptLoad()
    truce:loadDependencies()
    OnStart()
end

function OnStart()
    truce:onStart()
end

function OnJoin(id)
    truce:onJoin(id)
end

function OnQuit(id)
    truce:onQuit(id)
end

function OnTick()
    return truce:onTick()
end

function OnDamage(victim, killer)
    return truce:onDamage(victim, killer)
end

function OnCommand(id, command)
    return truce:onCommand(id, command)
end

function OnScriptUnload()
    -- N/A
end
