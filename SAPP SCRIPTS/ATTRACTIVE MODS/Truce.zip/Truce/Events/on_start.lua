local event = {}

function event:onStart()
    if (get_var(0, '$gt') ~= 'n/a') then
        for i = 1, 16 do
            if player_present(i) then
                self.players[i] = self:newPlayer({
                    id = i,
                    name = get_var(i, '$name'),
                })
            end
        end
    end
end

register_callback(cb['EVENT_GAME_START'], 'OnStart')

return event