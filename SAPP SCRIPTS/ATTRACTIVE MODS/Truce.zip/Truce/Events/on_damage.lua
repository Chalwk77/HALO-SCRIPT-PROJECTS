local event = {}

function event:onDamage(victim, killer)

    victim = tonumber(victim)
    killer = tonumber(killer)

    if (killer == 0) then
        return true
    elseif (self:isTruced(victim, killer)) then
        return false
    end

    return true
end

register_callback(cb['EVENT_DAMAGE_APPLICATION'], 'OnDamage')

return event