local event = {}

local time = os.time

function event:onTick()

    --
    -- Check for expired truce requests.
    for _, v in pairs(self.players) do
        local requests = v.requests
        for j = 1, #requests do
            local request = requests[j]
            local grace = request.grace
            if (time() >= grace) then
                requests[j] = nil
                rprint(request.receiver, 'Truce request from ' .. request.sender_name .. ' has expired.')
                rprint(request.sender, 'Truce request to ' .. request.receiver_name .. ' has expired.')
            --else
            --    print("Request will expire in " .. (grace - time()) .. " seconds.")
            end
        end
    end


end

register_callback(cb['EVENT_TICK'], 'OnTick')

return event