local event = {}

function event:onQuit(id)

    for i, v in pairs(self.players) do
        if (i ~= id) then

            local requests = v.requests
            for j, request in pairs(requests) do
                if (request.sender == id) then
                    requests[j] = nil
                end
            end

            local truces = v.truces
            for j, truce in pairs(truces) do
                if (truce.sender == id) then
                    truces[j] = nil
                end
            end
        end
    end

    self.players[id] = nil
end

register_callback(cb['EVENT_LEAVE'], 'OnQuit')

return event