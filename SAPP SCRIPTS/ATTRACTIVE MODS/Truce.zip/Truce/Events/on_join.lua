local event = {}

function event:onJoin(id)
    self.players[id] = self:newPlayer({
        id = id,
        name = get_var(id, '$name'),
    })
end

register_callback(cb['EVENT_JOIN'], 'OnJoin')

return event