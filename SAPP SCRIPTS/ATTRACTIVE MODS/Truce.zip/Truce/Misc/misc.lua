local misc = {}

-- Checks if a command is enabled/disabled.
-- @param enabled (boolean, -> command file 'enabled' property)
-- @param name (string -> command file name property)
-- @return true/false
--
function misc:commandEnabled(enabled, name)

    if (enabled) then
        return true
    end

    rprint(self.id, 'Sorry, /' .. name .. ' is disabled.')
    return false
end

-- Checks if player has permission to execute a command.
-- @param level (number, -> command file permission level property)
-- @return true/false
--
function misc:hasPermission(level)

    local lvl = tonumber(get_var(self.id, '$lvl'))
    if (lvl >= level) then
        return true
    end

    rprint(self.id, 'Insufficient Permission')
    return false
end

function misc:isTruced(victim, killer)

    local player = self.players[killer]
    local truces = player.truces

    for i = 1, #truces do
        local truce = truces[i]
        if (truce.receiver == victim) or (truce.sender == victim) then
            return true
        end
    end

    return false
end

return misc