local player = {}

function player:newPlayer(o)

    setmetatable(o, { __index = self })
    self.__index = self

    o.truces = {}
    o.requests = {}

    return o
end

return player