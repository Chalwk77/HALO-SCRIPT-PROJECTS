local Command = {}

-- Executes this command.
-- @param id = player id (number)
-- @param args (table of command strings)
--
function Command:run(id, args)

    local p = self.players[id] -- sender
    local request_id = tonumber(args[2])

    if not p:commandEnabled(self.enabled, self.name) then
        return
    elseif not p:hasPermission(self.level) then
        return
    elseif (not args[2]) then
        rprint(p.id, self.help)
        return
    end

    for i, v in ipairs(self.players) do
        if (i ~= id) then
            local requests = v.requests
            local request = requests[request_id]
            if (request) then
                requests[request_id] = nil
                rprint(id, 'Deleting request ' .. request_id .. ' from ' .. v.name .. '.')
                goto done
            else
                rprint(id, 'Request #' .. request_id .. ' not found for ' .. v.name .. '.')
                goto done
            end
        end
    end

    rprint(id, 'No pending requests found.')

    :: done ::
end

return Command