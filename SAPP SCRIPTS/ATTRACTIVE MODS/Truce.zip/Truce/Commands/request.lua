local Command = {}

local time = os.time

-- Executes this command.
-- @param id = player id (number)
-- @param args (table of command strings)
--
function Command:run(id, args)

    local target = tonumber(args[2])
    local sender = self.players[id]
    local receiver = self.players[target]

    if not sender:commandEnabled(self.enabled, self.name) then
        return
    elseif not sender:hasPermission(self.level) then
        return
    elseif (not target) then
        rprint(sender.id, self.help)
        return
    elseif (not player_present(target)) then
        rprint(id, 'Invalid player id.')
        return
    elseif (sender.id == receiver.id) then
        rprint(sender.id, 'You cannot send a truce request to yourself.')
        return
    end

    self:sendRequest(sender, receiver)
end

-- Sends a truce request to the receiver.
-- @param sender = player object
-- @param receiver = player object
--
function Command:sendRequest(sender, receiver)

    local requests = receiver.requests

    requests[#requests + 1] = {
        id = #requests + 1,
        sender = sender.id,
        receiver = receiver.id,
        sender_name = sender.name,
        receiver_name = receiver.name,
        grace = time() + self.grace_period
    }

    -- to receiver:
    rprint(receiver.id, sender.name .. ' has requested a truce with you [ID: ' .. #requests .. '].')
    rprint(receiver.id, 'Type /accept [id] or /decline [id]')

    -- to sender:
    rprint(sender.id, 'Truce request sent to ' .. receiver.name .. '.')
end

return Command