local Command = {}

local function deleteRequest(receiver, request, request_id)

    local sender_id = request.sender
    local sender = self.players[sender_id]

    rprint(receiver.id, "You have declined " .. sender.name .. "'s truce request.")
    rprint(sender.id, receiver.name .. ' has declined your truce request.')

    receiver.requests[request_id] = nil
end

-- Executes this command.
-- @param id = player id (number)
-- @param args (table of command strings)
--
function Command:run(id, args)

    local p = self.players[id] -- receiver
    local requests = p.requests -- table of requests

    if not p:commandEnabled(self.enabled, self.name) then
        return
    elseif not p:hasPermission(self.level) then
        return
    elseif (not args[2]) then
        rprint(p.id, self.help)
        return
    elseif (#requests == 0) then
        rprint(p.id, 'You have no pending requests.')
        return
    end

    local request_id = tonumber(args[2])
    local request = requests[request_id] -- request object

    if (not request) then
        rprint(p.id, 'Invalid request id.')
        rprint(p.id, 'Use /inbound to view your pending requests.')
        return
    end

    deleteRequest(p, request, request_id)
end

return Command