local Command = {}

-- Executes this command.
-- @param id = player id (number)
-- @param args (table of command strings)
--
function Command:run(id, args)

    local p = self.players[id]
    local truces = p.truces

    if not p:commandEnabled(self.enabled, self.name) then
        return
    elseif not p:hasPermission(self.level) then
        return
    elseif (not args[2]) then
        rprint(p.id, self.help)
        return
    elseif (#truces == 0) then
        rprint(p.id, 'You are not truced with anyone.')
        return
    end

    local truce_id = tonumber(args[2])
    local truce = truces[truce_id] -- truces object

    if (not truce) then
        rprint(p.id, 'Invalid truce id.')
        return
    end

    local sender = self.players[truce.sender]
    local receiver = self.players[truce.receiver]

    sender.truces[truce_id] = nil -- removes entry for sender
    receiver.truces[truce_id] = nil -- removes entry for receiver

    if (sender.id == id) then
        rprint(p.id, 'You have untruced ' .. receiver.name .. '.')
        rprint(receiver.id, p.name .. ' has untruced you.')
        return
    elseif (receiver.id == id) then
        rprint(p.id, 'You have untruced ' .. sender.name .. '.')
        rprint(sender.id, p.name .. ' has untruced you.')
        return
    end
end

return Command