local Command = {}

local time = os.time

function Command:run(id, args)

    local p = self.players[id]

    if not p:commandEnabled(self.enabled, self.name) then
        return
    elseif not p:hasPermission(self.level) then
        return
    elseif (args[2]) then
        rprint(p.id, self.help)
        return
    end

    local t = {}
    for i, v in ipairs(self.players) do
        if (i ~= id) then
            for j, request in pairs(v.requests) do
                local grace = request.grace
                local sender = request.sender
                t[#t+1] = (sender == id) and v.name .. ' [ID: ' .. j .. '], Expires in ' .. grace - time() .. ' seconds.' or nil
            end
        end
    end

    if (#t == 0) then
        rprint(p.id, 'You have no outgoing requests.')
        return
    end

    rprint(p.id, 'Outgoing Requests:')
    for _, v in ipairs(t) do
        rprint(p.id, v)
    end
end

return Command