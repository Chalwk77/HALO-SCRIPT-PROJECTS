local Command = {}

-- Executes this command.
-- @param id = player id (number)
-- @param args (table of command strings)
--
function Command:run(id, args)

    local p = self.players[id] -- receiver
    local requests = p.requests -- table of requests

    if not p:commandEnabled(self.enabled, self.name) then
        return
    elseif not p:hasPermission(self.level) then
        return
    elseif (not args[2]) then
        rprint(p.id, self.help)
        return
    elseif (#requests == 0) then
        rprint(p.id, 'You have no pending requests.')
        return
    end

    local request_id = tonumber(args[2])
    local request = requests[request_id] -- request object

    if (not request) then
        rprint(p.id, 'Invalid request id.')
        rprint(p.id, 'Use /requests to view your pending requests.')
        return
    end

    local sender_id = request.sender
    local sender = self.players[sender_id]

    self:newTruce(sender, p)

    p.requests[request_id] = nil
end

local function addTruce(sender, receiver, t)
    t[#t + 1] = {
        id = #t + 1,
        sender = sender.id,
        receiver = receiver.id,
        sender_name = sender.name,
        receiver_name = receiver.name
    }
    return t
end

function Command:newTruce(sender, receiver)

    local sender_truces = sender.truces
    local receiver_truces = receiver.truces

    addTruce(sender, receiver, sender_truces)
    addTruce(sender, receiver, receiver_truces)

    rprint(receiver.id, 'You are now in a truce with ' .. sender.name .. '.')
    rprint(sender.id, 'You are now in a truce with ' .. receiver.name .. '.')
end

return Command