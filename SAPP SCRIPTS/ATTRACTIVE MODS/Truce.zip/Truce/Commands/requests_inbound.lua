local Command = {}

local time = os.time

function Command:run(id, args)

    local p = self.players[id] -- receiver
    local requests = p.requests -- table of requests

    if not p:commandEnabled(self.enabled, self.name) then
        return
    elseif not p:hasPermission(self.level) then
        return
    elseif (args[2]) then
        rprint(p.id, self.help)
        return
    elseif (#requests == 0) then
        rprint(p.id, 'You have no incoming requests.')
        return
    end

    for i, request in pairs(requests) do
        local grace = request.grace
        local sender_id = request.sender
        local sender = self.players[sender_id]
        rprint(p.id, sender.name .. ' [ID: ' .. i .. '], Expires in ' .. grace - time() .. ' seconds.')
    end
end

return Command