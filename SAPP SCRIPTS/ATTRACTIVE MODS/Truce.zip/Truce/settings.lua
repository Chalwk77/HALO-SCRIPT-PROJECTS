return {

    --
    -- Commands to load.
    -- Each command is a file in the Commands folder.
    -- Each command inherits the parent truce object from the main sapp script.
    -- Commands can be enabled or disabled (true/false).
    commands = {
        ['accept'] = {
            enabled = true,
            name = 'accept',
            description = 'Accept a truce request.',
            level = 4,
            help = 'Syntax: /$cmd [truce id]'
        },
        ['cancel'] = {
            enabled = true,
            name = 'cancel',
            description = 'Cancel a truce request before it gets accepted',
            level = 4,
            help = 'Syntax: /$cmd [request id]'
        },
        ['decline'] = {
            enabled = true,
            name = 'decline',
            description = 'Decline a truce request.',
            level = 4,
            help = 'Syntax: /$cmd [player id]'
        },
        ['list'] = {
            enabled = true,
            name = 'trucelist',
            description = 'Get a list of players that you are truced with.',
            level = 4,
            help = 'Syntax: /$cmd'
        },
        ['request'] = {
            enabled = true,
            name = 'truce',
            description = 'Send a truce request to a player.',
            level = 4,
            help = 'Syntax: /$cmd [player id]'
        },
        ['requests_inbound'] = {
            enabled = true,
            name = 'inbound',
            description = 'Get a list of inbound requests.',
            level = 4,
            help = 'Syntax: /$cmd'
        },
        ['requests_outbound'] = {
            enabled = true,
            name = 'outbound',
            description = 'Get a list of outbound requests',
            level = 4,
            help = 'Syntax: /$cmd'
        },
        ['untruce'] = {
            enabled = true,
            name = 'untruce',
            description = 'Untruce a player.',
            level = 4,
            help = 'Syntax: /$cmd [truce id]'
        }
    },

    --
    -- The amount of time (in seconds) that a player has to accept a truce request.
    grace_period = 60
}